-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1731073796,1731073796,0,0,0,0,'69b08930d26ea2f48c11d1535748d9cded293b53',1,'My dashboard','{\"23eab24bfbc5ba085a8cd4439d74752d12e975b9\":{\"identifier\":\"t3information\"},\"944563c701b7ffef5004b9762b395a06a497ba5e\":{\"identifier\":\"docGettingStarted\"}}'),
(2,0,1764860534,1764860534,0,0,0,0,'ad6bbf19c7afc05d2c005ccf4162eae820f5d6bb',3,'My dashboard','{\"f76cf5a186a1585956123d29569ec07c3261a8aa\":{\"identifier\":\"t3information\"},\"1f25a26e9457dc143562dc548b35c21ac46fae43\":{\"identifier\":\"docGettingStarted\"},\"627dcf5a3a281e415e9be20d83b1f32bc3298717\":{\"identifier\":\"sysLogErrors\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `db_mountpoints` longtext DEFAULT NULL,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('7fec6f44dec5e41454cc409e0debb7c429b3b63abcb43c7302470a7dcebc278a','[DISABLED]',3,1782831474,'a:2:{s:26:\"formProtectionSessionToken\";s:64:\"6f9345e165893b4d13bbacca864fddd2bed1f3d62b6669ae3d03454ff7a329f1\";s:22:\"tx_sitescore_collapsed\";b:0;}'),
('a5cc03e7b828e5b26fb274ced255e201f200a89a2b99cbf33b7d771896ca8498','[DISABLED]',3,1788346805,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"291468ad8402583f37be3d50d43450550c4512f51e4b9fcf214f1193487aa5f5\";}'),
('eb36c2c82e5826f2ae0888cbbc911c5988b01535284f34a8237dd9f1eacd5a33','[DISABLED]',3,1782831672,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"6dee063b09b9e9705e8eb3957e19215d800761e6cf5ab9a0663754728a922e71\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(512) DEFAULT '',
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `TSconfig` longtext DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `tsconfig_includes` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1764860506,1731073356,1,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$SWRVVGRtYzg3c1RzNHloZQ$dZW3HSj9M8S5W3uzv7078Gl1PVqbh6EUian5/sRDrnE',1,NULL,'default','',NULL,0,'',NULL,'','a:9:{s:10:\"moduleData\";a:14:{s:28:\"dashboard/current_dashboard/\";s:40:\"69b08930d26ea2f48c11d1535748d9cded293b53\";s:6:\"web_ts\";a:1:{s:6:\"action\";s:25:\"web_typoscript_infomodify\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}}s:10:\"FormEngine\";a:2:{i:0;a:2:{s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:19:\"The fiith Continent\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=41f134f55744585070a75fc228d691f5d832e2b1&id=4#element-tt_content-3\";}s:32:\"deac478137dd48a97e299bd046412e21\";a:5:{i:0;s:8:\"Glossary\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=41f134f55744585070a75fc228d691f5d832e2b1&id=3&#element-tt_content-2\";}}i:1;s:32:\"781003bb54284ba8b56dd4bb0a4d5808\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:8:{s:32:\"781003bb54284ba8b56dd4bb0a4d5808\";a:5:{i:0;s:9:\"Australia\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:60:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"0650189cb5a009745b874ca6b3a2fdeb\";a:5:{i:0;s:6:\"Zambia\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:25;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B25%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:25;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"d8935b1949ed70ec5e14171249a2f5f1\";a:5:{i:0;s:5:\"Yemen\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:24;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B24%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:24;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"f1a868e682c4ccf37af23a7ae439bea9\";a:5:{i:0;s:7:\"Vietnam\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:23;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B23%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:23;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"291b8c79315cf57ebd82db51292e1c3e\";a:5:{i:0;s:5:\"Spain\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:22;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B22%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:22;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"ed1f42aba6818a9a5b7638d66a28dbdb\";a:5:{i:0;s:4:\"Oman\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:21;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B21%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:21;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"0f867acdf36780344d94106148fda72e\";a:5:{i:0;s:6:\"Norway\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:20;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B20%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:20;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}s:32:\"15453983ca884f778a27f03fc8ca4bbe\";a:5:{i:0;s:10:\"Luxembourg\";i:1;a:5:{s:4:\"edit\";a:1:{s:37:\"tx_in2glossar_domain_model_definition\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_in2glossar_domain_model_definition%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_in2glossar_domain_model_definition\";s:3:\"uid\";i:19;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=56a63d9f756849d710e6bcfadb9879091b7a1a7d&id=2&table=&pointer=1\";}}s:23:\"web_typoscript_analyzer\";a:3:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:16:\"browse_links.php\";N;s:8:\"web_list\";a:1:{s:15:\"collapsedTables\";a:1:{s:10:\"tt_content\";s:1:\"0\";}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:8:\"web_info\";a:1:{s:6:\"action\";s:17:\"web_info_overview\";}s:15:\"system_BelogLog\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:16:\"selectedCategory\";s:20:\"plugin.tx_in2glossar\";}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:13:{s:28:\"dashboard/current_dashboard/\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:6:\"web_ts\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";s:25:\"web_typoscript_infomodify\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:10:\"FormEngine\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:16:\"opendocs::recent\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:23:\"web_typoscript_analyzer\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:16:\"browse_links.php\";s:40:\"93dee441ec16d376535d649db1c6b0aa7691667e\";s:9:\"clipboard\";s:40:\"61f1746f153cade735946f89d3dffa6bb74b5a7b\";s:8:\"web_info\";s:40:\"417be151122b448bc4a2b6fd0849aed538f0d365\";s:15:\"system_BelogLog\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";s:29:\"web_typoscript_constanteditor\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";s:17:\"typoscript_active\";s:40:\"fda4289544c9423811da71e9ccf380d20a46f9c1\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:1:{s:3:\"0_1\";s:1:\"1\";}}}}s:10:\"modulemenu\";s:2:\"{}\";s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1731507258}}\";s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"300\";}}',NULL,NULL,1,NULL,0,NULL,NULL,1737016838,'',NULL,''),
(2,0,1731073578,1731073578,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$eHJ4RmpteG5FTi4uTFIxcw$i4ES61/csL/GY0Bdp/ecznc0DQBajNzDcc/k9mBbMpQ',1,NULL,'default','',NULL,0,'',NULL,'','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',NULL,NULL,1,NULL,0,NULL,NULL,0,'',NULL,''),
(3,0,1767091817,1764860180,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$N0xndTBkTnhsM1lnUzNzbw$UpjpeIio43IjlLY+MPtdMWEmKlCHRhvDAEfv51EPL0g',1,NULL,'default','',NULL,0,'',NULL,'','a:21:{s:10:\"moduleData\";a:7:{s:10:\"FormEngine\";a:2:{i:0;a:8:{s:32:\"629911c017052e9e049ce359020150c0\";a:5:{i:0;s:8:\"Taubheit\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:7;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:119:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4&function=2&language=0#element-tt_content-7\";}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:14:\"Der Dalmatiner\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4#element-tt_content-3\";}s:32:\"ca1d9f585ca31e6d709268bfa0021f7e\";a:5:{i:0;s:4773:\"Haltung und Pflege des Dalmatiners\r\n    \r\n    \r\n        Der Dalmatiner ist ein aktiver und energiegeladener Hund, der viel Bewegung und Beschäftigung benötigt. Diese Hunderasse eignet sich besonders für sportliche Menschen, die gerne joggen, Rad fahren oder ausgedehnte Wanderungen unternehmen. Ein Dalmatiner braucht täglich mindestens zwei Stunden Auslauf, um seinen natürlichen Bewegungsdrang auszuleben.\r\n        \r\n        Die Pflege des Dalmatiners ist vergleichsweise unkompliziert. Das kurze, glatte Fell haart zwar das ganze Jahr über, lässt sich aber mit regelmäßigem Bürsten gut in den Griff bekommen. Baden sollte man den Dalmatiner nur bei Bedarf, um die natürliche Schutzschicht der Haut nicht zu zerstören.\r\n    \r\n\r\n\r\n\r\n    \r\n        Charakter und Wesen des Dalmatiners\r\n    \r\n    \r\n        Der Dalmatiner zeichnet sich durch sein freundliches und aufgeschlossenes Wesen aus. Diese Hunderasse ist intelligent, lernwillig und möchte seinem Menschen gefallen. Dalmatiner sind sehr menschenbezogen und bauen eine enge Bindung zu ihrer Familie auf. Sie eignen sich gut als Familienhunde, wenn sie ausreichend beschäftigt werden.\r\n        \r\n        Wichtig ist bei der Erziehung des Dalmatiners eine konsequente, aber liebevolle Hand. Die Rasse kann manchmal etwas stur sein, reagiert aber sehr gut auf positive Verstärkung. Dalmatiner sind sensibel und sollten niemals mit Härte behandelt werden. Mit der richtigen Erziehung wird der Dalmatiner zu einem treuen und gehorsamen Begleiter.\r\n    \r\n\r\n\r\n\r\n    \r\n        Ernährung und Gesundheit beim Dalmatiner\r\n    \r\n    \r\n        Bei der Ernährung des Dalmatiners gibt es einige Besonderheiten zu beachten. Die Rasse neigt zu Harnsteinen, weshalb eine purinarme Ernährung empfohlen wird. Hochwertiges Hundefutter mit einem ausgewogenen Protein- und Mineralstoffgehalt ist für den Dalmatiner besonders wichtig. Viele Züchter und Tierärzte empfehlen, auf Innereien und bestimmte Fleischsorten zu verzichten.\r\n        \r\n        Neben der Taubheit, die bei Dalmatinern gehäuft vorkommt, sind die meisten Vertreter dieser Rasse gesundheitlich robust. Regelmäßige tierärztliche Kontrollen, Impfungen und eine gute Vorsorge tragen dazu bei, dass der Dalmatiner ein langes und gesundes Leben führen kann. Die durchschnittliche Lebenserwartung liegt bei 10 bis 13 Jahren.\r\n    \r\n\r\n\r\n\r\n    \r\n        Dalmatiner als Familienhund\r\n    \r\n    \r\n        Der Dalmatiner kann ein wunderbarer Familienhund sein, wenn die Rahmenbedingungen stimmen. Die Rasse ist kinderlieb und geduldig, benötigt aber genügend Platz und Beschäftigung. Ein Haus mit Garten ist ideal für die Haltung eines Dalmatiners, wobei auch eine Wohnungshaltung möglich ist, wenn ausreichend Bewegung geboten wird.\r\n        \r\n        Familien, die einen Dalmatiner halten möchten, sollten aktiv sein und gerne Zeit im Freien verbringen. Der Dalmatiner liebt es, überall dabei zu sein und am Familienleben teilzuhaben. Mit seiner fröhlichen und verspielten Art bringt der Dalmatiner viel Freude ins Haus und wird schnell zum vollwertigen Familienmitglied.\r\n    \r\n\r\n\r\n\r\n    \r\n        Dalmatiner kaufen: Worauf achten?\r\n    \r\n    \r\n        Wer einen Dalmatiner kaufen möchte, sollte sich an seriöse Züchter wenden, die einem anerkannten Zuchtverband angehören. Ein verantwortungsvoller Züchter wird die Welpen auf Taubheit testen lassen und kann Auskunft über die Elterntiere und deren Gesundheit geben. Der Preis für einen Dalmatiner-Welpen liegt in der Regel zwischen 1.200 und 1.800 Euro.\r\n        \r\n        Alternativ kann man auch einem Dalmatiner aus dem Tierschutz eine Chance geben. Viele erwachsene Dalmatiner suchen ein neues Zuhause und freuen sich über eine zweite Chance. Wichtig ist in jedem Fall, dass man sich vor der Anschaffung ausführlich über die Bedürfnisse der Rasse informiert und sicherstellt, dass man dem Dalmatiner ein artgerechtes Leben bieten kann.\r\n    \r\n\r\n\r\n\r\n    \r\n        Fazit: Der Dalmatiner als besondere Hunderasse\r\n    \r\n    \r\n        Der Dalmatiner ist zweifellos eine ganz besondere Hunderasse mit unverwechselbarem Aussehen und liebenswerten Charaktereigenschaften. Mit seinem getupften Fell und seinem eleganten Erscheinungsbild zieht der Dalmatiner überall die Blicke auf sich. Doch hinter der schönen Fassade steckt ein anspruchsvoller Hund, der viel Bewegung, konsequente Erziehung und eine enge Bindung zu seinen Menschen braucht.\r\n        \r\n        Für aktive Menschen und Familien, die bereit sind, Zeit und Energie in die Haltung zu investieren, ist der Dalmatiner ein treuer und fröhlicher Begleiter. Mit der richtigen Pflege, Ernährung und Beschäftigung wird der Dalmatiner zu einem glücklichen und ausgeglichenen Familienmitglied, das viele Jahre Freude bereitet.\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:13;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B13%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:13;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4\";}s:32:\"c72d4a5ffd106794d45e5a4a941814ba\";a:5:{i:0;s:4:\"Temp\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:2;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=f0cc3517d8027904f65e63350e39447f45d60310&id=4&table=&pointer=1\";}s:32:\"c31c3d00814edbf9b2ddab640af3f55d\";a:5:{i:0;s:1292:\"{\r\n  &quot;@context&quot;: &quot;https://schema.org&quot;,\r\n  &quot;@type&quot;: &quot;Article&quot;,\r\n  &quot;headline&quot;: &quot;Der Dalmatiner - Charakter, Haltung &amp; Wissenswertes zur Hunderasse&quot;,\r\n  &quot;description&quot;: &quot;Alles über den Dalmatiner: Charakter, Aussehen, Geschichte und Besonderheiten der getupften Hunderasse. Erfahren Sie mehr über Haltung und Zucht.&quot;,\r\n  &quot;image&quot;: [\r\n    &quot;https://example.com/fileadmin/_processed_/b/e/csm_SallyMohnfeld_65f021491a.jpg&quot;,\r\n    &quot;https://example.com/fileadmin/_processed_/b/5/csm_SallySchnauze_0e76d1b3bc.jpg&quot;\r\n  ],\r\n  &quot;author&quot;: {\r\n    &quot;@type&quot;: &quot;Organization&quot;,\r\n    &quot;name&quot;: &quot;in2code GmbH&quot;\r\n  },\r\n  &quot;publisher&quot;: {\r\n    &quot;@type&quot;: &quot;Organization&quot;,\r\n    &quot;name&quot;: &quot;in2code GmbH&quot;,\r\n    &quot;logo&quot;: {\r\n      &quot;@type&quot;: &quot;ImageObject&quot;,\r\n      &quot;url&quot;: &quot;https://example.com/logo.png&quot;\r\n    }\r\n  },\r\n  &quot;datePublished&quot;: &quot;2025-01-06&quot;,\r\n  &quot;dateModified&quot;: &quot;2025-01-06&quot;,\r\n  &quot;mainEntityOfPage&quot;: {\r\n    &quot;@type&quot;: &quot;WebPage&quot;,\r\n    &quot;@id&quot;: &quot;https://example.com/dalmatiner&quot;\r\n  }\r\n}\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:14;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B14%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:14;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4&\";}s:32:\"61765c6a3de2e0ba09d6230397278147\";a:5:{i:0;s:8:\"Deafness\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:12;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B12%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:12;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:120:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4&function=2&language=1#element-tt_content-12\";}s:32:\"37f3f7a23a142dde5d82d39b74f95c1d\";a:5:{i:0;s:19:\"Der Dackel (Teckel)\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:15;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B15%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:15;s:3:\"pid\";i:7;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=7\";}s:32:\"1edd15adf43123aaf034d44a97cf558b\";a:5:{i:0;s:1363:\"Die Dackel, auch Dachshund oder vor allem in der Jägersprache Teckel genannt, sind neun von der FCI anerkannte deutsche Hunderassen (FCI-Gruppe&amp;nbsp;4, Sektion&amp;nbsp;1, Standard Nr.&amp;nbsp;148).\r\nDie Rassen werden in drei unterschiedlichen Fellformen und drei unterschiedlichen Größenformen gezüchtet, woraus die neun verschiedenen Rassen definieren, welche regulär nicht miteinander gekreuzt werden und zudem unterschiedliche genetische Herkünfte vorweisen. Die Zucht findet in Deutschland hauptsächlich im Deutschen Teckelklub 1888, im Internationalen Rasse-Jagd-Gebrauchshundeverband und – als rein jagdliche Zucht – im Verein für Jagdteckel[1] statt.\r\nDer Begriff Dachshund bezeichnet neben der Hunderasse auch eine historische Nutzungsgruppe von Jagdhunden: zum einen Hunde, die zur Baujagd (Erdhund), nicht aber speziell zur Jagd im Dachsbau eingesetzt wurden, denn Dachse sind sehr wehrhaft und damit gefährlich für die Erdhunde. Vielmehr ist der Namensbestandteil Dachs eine übergreifende Hunderassenbezeichnung als ein Hinweis auf die Größe der Hunde und eine Gruppe (Gruppe 4: Dachshunde) in der Rassesystematik der FCI, die dort jedoch nur die Rasse Dachshund enthält. Weitere Namensträger sind die Westfälische Dachsbracke und die Alpenländische Dachsbracke, bei denen es sich nicht um Rassen der Gruppe Erdhunde handelt.\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:16;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B16%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:16;s:3:\"pid\";i:7;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=7\";}}i:1;s:32:\"b4ebb2474e05a65466f2a0872f322b9b\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:28:\"dashboard/current_dashboard/\";s:40:\"ad6bbf19c7afc05d2c005ccf4162eae820f5d6bb\";s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:15:\"1:/user_upload/\";}s:10:\"web_layout\";a:5:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:8:\"function\";s:1:\"2\";s:8:\"language\";s:2:\"-1\";s:9:\"languages\";a:1:{i:0;i:0;}}s:16:\"opendocs::recent\";a:8:{s:32:\"b4ebb2474e05a65466f2a0872f322b9b\";a:5:{i:0;s:16:\"Standard Content\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B4%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=7cc2403e48b665928fdb063a1f9eed2ed6dd5d35&id=4&function=2&language=1\";}s:32:\"c72d4a5ffd106794d45e5a4a941814ba\";a:5:{i:0;s:4:\"Temp\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:2;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=f0cc3517d8027904f65e63350e39447f45d60310&id=4&table=&pointer=1\";}s:32:\"af6a208f792a83220f87a953a62a081a\";a:5:{i:0;s:10:\"Geschichte\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:6;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:119:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4&function=2&language=0#element-tt_content-6\";}s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";a:5:{i:0;s:12:\"Beschreibung\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:119:\"/typo3/module/web/layout?token=70e320e545e5f2f9a2f70234971d00b2cddd0265&id=4&function=2&language=0#element-tt_content-4\";}s:32:\"918a753303152549162ace69e9b35e6d\";a:5:{i:0;s:39:\"[Translate to German:] Standard Content\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"1\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B5%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=1\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:5;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=7cc2403e48b665928fdb063a1f9eed2ed6dd5d35&id=4&function=2&language=1\";}s:32:\"61765c6a3de2e0ba09d6230397278147\";a:5:{i:0;s:31:\"[Translate to German:] Taubheit\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:12;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B12%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:12;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=7cc2403e48b665928fdb063a1f9eed2ed6dd5d35&id=4#element-tt_content-12\";}s:32:\"9c43855926e54a70d4d0a190cb54db8c\";a:5:{i:0;s:33:\"[Translate to German:] Geschichte\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:11;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B11%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:11;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=7cc2403e48b665928fdb063a1f9eed2ed6dd5d35&id=4#element-tt_content-11\";}s:32:\"ffbd6ae78a9aa555f88d6295c30fb80c\";a:5:{i:0;s:38:\"[Translate to German:] Zuchtausschluß\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:10;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=7cc2403e48b665928fdb063a1f9eed2ed6dd5d35&id=4#element-tt_content-10\";}}s:8:\"web_list\";a:1:{s:15:\"collapsedTables\";a:1:{s:10:\"tt_content\";s:1:\"1\";}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:6:{s:10:\"FormEngine\";s:40:\"1ec1801e21d4b3530d41892686f19fb628cf00d7\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"1ec1801e21d4b3530d41892686f19fb628cf00d7\";s:28:\"dashboard/current_dashboard/\";s:40:\"8fd259b92905c684847a31aaa39f6aeab555aceb\";s:16:\"browse_links.php\";s:40:\"822e1f95265bc693db11e5c2b4f8618315d83a5d\";s:10:\"web_layout\";s:40:\"b1abc10dc0e66eda5719e5a6ba1ec85570098262\";s:16:\"opendocs::recent\";s:40:\"1ec1801e21d4b3530d41892686f19fb628cf00d7\";}s:10:\"modulemenu\";s:2:\"{}\";s:10:\"inlineView\";s:171:\"{\"tt_content\":{\"4\":{\"sys_file_reference\":[1]},\"NEW694a69afeb6d5884666623\":{\"sys_file_reference\":[2]},\"9\":{\"sys_file_reference\":{\"1\":\"\"}},\"6\":{\"sys_file_reference\":[\"2\"]}}}\";s:11:\"colorScheme\";s:5:\"light\";s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:4:\"lang\";s:0:\"\";s:11:\"startModule\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:10:\"copyLevels\";s:0:\"\";s:18:\"resetConfiguration\";s:0:\"\";s:12:\"mfaProviders\";s:0:\"\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:5:\"theme\";s:6:\"modern\";}',NULL,NULL,1,NULL,0,NULL,NULL,1788346785,'','{\"emailMeAtLogin\":0,\"password2\":\"\",\"mfaProviders\":\"\",\"colorScheme\":\"light\",\"theme\":\"modern\",\"startModule\":\"\",\"backendTitleFormat\":\"titleFirst\",\"titleLen\":\"50\",\"edit_docModuleUpload\":1,\"showHiddenFilesAndFolders\":0,\"copyLevels\":\"\"}','');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--

LOCK TABLES `cache_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--

LOCK TABLES `cache_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'1_654239d5324caab2',1819882960,'x��X[o�����W0D���̋.��@�{�v�XE[�E0$�IH��Ѧ��=g��(Y�&��69sn߹�,��諌�Ȯ�>��~�#�>ID��T6�y��F�������?�ϭ�*�ޔ�X9+��v\n��s�΀�\'=�(f%VKP��Re�)z�W�����l�����\n,|��ԐZ��B�V�⥬x�˹U��r���$ʃWȮi��YY\r`�\nJK�e��uj,�nY��\nz��YO���B��,��VRSF�oLVP[�������y���e�����ߜ������DT����&�����پ�#���#�(��\Z:lH��k�dI_!��j�j��L�Sȧ��x�<^��AP��G�+18��������Tq��ɕ(`��	F�N8��\Z��m51>�\r���[K�y��ʏm��9����E\rٱm*(*�I�t)���FI�Y2ʲ�ţ`4pc��\\w�%�#$��RΎmt����Օ�R�<ay����K�H��4��勣��1�6�E��?Rբ��Z�V��J��\\q���Ӑ������4�+��h����ܱ�Q�X�w?��-sռ���\"��2���E��b���}�#]���cU�Osn�z;D�,�޵��KsX�K���o�s\0���&A�29K�����y7�oA�������O���%D}��j�\n���i�헖.�c�{�˩����j#KV�<�%�<��ú��b���g��,���y�C�5����ӆ�G������m�`c0�j�4���#P�Fo3*g���F��/J�ٌ@3�ŏ��/�����X���g��$�\04s�~X�c�{��� �;j<��a�1����c?HY��{�N;m�?�D6�.�~2�+x\'/jQ\\钚�!&�8r�cٹ�����2�q����T��xC��w=��ظB�tT��_i�Q[dC�����h�H���Qwt5�W�X�@\\N}�6�)<@K�3�[�����	)T�2� �H<�\r蓼���P�ᓼ�q���dۣ��.!*�UE�\0Mg�,Z[]c�\"���m_������-�3���EF�-bv�^�(EO4�:��/�U�1�v�3���t��Z4�nV����Dc9��RuB��\nu7T���v[���Zx����B�*Y��u0@���@����Zڿ���R���/��&:\"����\n�t���T�E�c�Pp������.#��8I!���}\0�vJ��+�wf\r#�t��s�mcu�d�\r�!�D���˲m�1�qj��.2ԋ�y�7Zd��b��Z�sDK�����C�k���cb��x����sHt_��>njE�v�I��N��R��Au>�E��R�y������X���K��	5�n�b�yQa�ܲ��=-36��L��vx��~G�E�ȩ\\7A�#woU���ŵ�B��ӶR�u���I�zl�9�t��˪*_߉2�+N�h�.�w,�0�{�A61�0d���\r�:o\r��y:���|�[\'ajT5~A�j��o��\"�X^k������D���D�O�:����V>kCG]C@l�|����f�⧱�9{�\n��).}?-���l�^�kx�s��6�?�NE��G$9����f��v�;���D�VB��T5���w(��h�S!���|�o�o�8DaF��t�o��.�͎�Zq:�[�]�����E��E3ꐽ[����bi{\0-k3\Z��,Y�&���`$5�����nޱ>V<���,��fԒ/MB:������}�0Ǔ�۔5Z\Z�6e:��z/��ێE���һ_Ә�2����h}��w���L���\\v:�=�}�~��a����װ\"�&a���,e��0��!~�g~\Z�$�d8��M�ɀ����xa�>��c�$L�A��Y�a0��\rq�fc7��8pǾ�_�n��');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_654239d5324caab2','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_0_0',1790938960,'x�}T�n�0�}@+J���4Es(|qr艠ȑLXU��c�������f{3� Ň,�V�i�a��)�Y��˫_!��E`�em1�1	�8I��µ`�,ih���� ��n�\"���Z�at�G�\"���Z\rX� � FG���]=;�Mhuzõ�TXh7&\0!m��qqE.�lhúz`5�am�`���홆���F\r�/�H8��2�݄٘*-k?o2y\nYUs��8����sg�d����T��^���5t0��ݒx�/C���ИL�=�Of���T�<gB�ŉ�[n�Y�0�L��=�0;�n^�\\u����a1i���R���V`����t�ՍK��1�9�0���.^1�*�K���tʀ�h�Y��N�L�`=\'�EU���G8��f��r�@����nГ���K���E}t�\Z`�|1�������ˏ��ݯ�O�f�&IG>�4V3n�D�v?\\5�.�-�܋�e��1^�l�88�?�A\n-���O�FoǙ�0�>��KǪ�VZ���krGr@����HU���!YGyu�	���!:oq�%�F�a�A����}x�,��x30�ms��\Z�nW�0c_{�\n�b���ʅ524�PO����F\Z�o�⎠e=���j��z�%Ӹ\r�/ǭ���wo�U�i�i�S��������\'�q�v���5�����A�N���IZ<���|��7P����J���3-��]|~�Q�m�\"�X�	3���4�URf\"Y���e�6y�3����\\�����D�p�� JK\0�m��|�1%cU��iI�9BG;'),
(2,'4__0_0_0_0',1790938960,'x��WMo�6�+�=m[}ْ��bS4�\"�dQ�DP$%�D���A�{G\")Qvڢ(v�r3ߐÙ�72.���\r.��xQER��\r/қi՛U�]h�q�O@�˲$�山I�fƒDa&I��(k�f����=pJY�}�W�5o���먏�EP1TK1���� 0����w��o7��E ��)\"y�����F�n9:�Ģ�\n5��\\3dS�lQ4QءK��+X�A�9�(t���po1� !y���ڝ�W�s���j�<>�U� �.���h�\Z�AH�7b-�AJL�P2��,��:��QÞ�=B090�q�Vk(��@65d���i���h�H�	�^�\r ���3���nV�Y����G�0�=��^2��d�~s��L\na�;��IHj6Q�!R��5X����Jꀥ4-D��OA����\'z+\r��%;}�+x\'�bX��Y��i�0@��/X8a�lx��r(���V3�+C�;��L?Oe�dȖd����t��$	C�Ԛ��,~�8q`�UhPL.*%�q}�r`D�Ⱥ���x��F180V�KA��XLQF9�㷸i1�\0����K|�|���F]��n�+W�u��$Ti�� 7wCG��\0[q��Y�Z̽h�����\Z�]=�5�B*O������dXv\Z�b7�a�\0je)�H�%ʲ	jc���y��ܻnv�<UX\\���KEf-M����o藏���>�����մ�xfe�A�	����%o+����X��b\Z�;�N�[&7ml�����Õ�-S�|���D�=�,Mn+�p!�K�����k��sV�!	����{���2.!��f!�pR+{я��Œ~oK�=\r��66I�{�K��s`�!�ak�C1�.ٝOl�Ж�^��Dӈ�\\�|�O0�Y%��~\0�y\':Np�.��â��z<���>�\'���������$�+�:�r^E�>�:�}�u��Μx_g�\r�%�m��י�|��3�Xx�y�x��:��V�h�����ߞ����W����s���g���(�f��,���}�������>�ʬ{��d�eY�2M�q�+3��a��{��X�Kض�Q��vd�J�<ަ�*�I��a��ўT	N�dGI�T�>	KJp\Z�q�g�NO�'),
(3,'7__0_0_0_0',1790938960,'x��U�n�6�}@G�,QVV���,\no�YtEP�LXU�\Z���{��M�i��\0���}����eR���<���Ŗi�JF����0�����YǻahNi�E2K���A(�JhIh���%�u�JJ�W`[F��8�:X14�^�HQF5����ے�Q͊V���+��W%�22��V58�1�nvR�V��� {���}3�ؒ�$�-�{6p�����8�#�\n���s)�F5��lє��W\'c�_�ҔQ�\Z͵q�70L��\n�5�]�78�΂�,-��K������A/�:Y��O���>UZ�VO(q؄)g��#h�VJ}p�ցÆ=?	�תY\n��eV90Z_Z�Y��\0橇U��LΑ~4{�{�1^��\'Ύՙ��)���/�~+�i�J�c��Ư#�t�F�%�+���c8��^������j��^3܈}8aO�?��>?=������_��ܒd��+�nv�y`��U�~=��U|�Oc5�� o>:,\\��� �����\'��n�Y�0�=�;�MǨ��Fw,í\'9� �$\0�n����虨��*���^���g*Iv+d=&�Z�0B�;8�%S�hG	Wm���������ܺ��*e�����ީ3u�i۱Y��<�\nZ�nZ������ͣ��-���߬�F���E��m����b��$��	l|����-�a�ƺ��M��e��n����\"�[C�M���L�2���cwm��Ӿ����\Z�{\\Ô�4Ͳ��\Z������[�{��G���u�f���Gnv��࿟�3珳��g7��7�8{?���έ�Qm>}ܺw�u�2��rB7Y���6�d�|�	@Nr.�$Ն�*�i%��m�9���\r�4�l�����iL�|[�y�MeMh�\'��z�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_0_0','pageId_1'),
(2,'4__0_0_0_0','pageId_1'),
(3,'4__0_0_0_0','pageId_4'),
(4,'7__0_0_0_0','pageId_1'),
(5,'7__0_0_0_0','pageId_7');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `TSconfig` longtext DEFAULT NULL,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` longtext DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `slug` text DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `contentFromPid` (`content_from_pid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1731073553,1731073553,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,0,NULL,0,0,0,0,1,1,31,31,1,'Home',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1731080457,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0),
(2,1,1764860267,1731077386,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Data',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/data','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0),
(3,1,1764860261,1731077439,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Glossary',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1736950581,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/glossary','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0),
(4,1,1767738682,1731080337,0,0,0,0,'',64,NULL,0,0,0,0,NULL,0,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"tx_sitescore_keyword\":\"\"}',0,0,0,0,1,0,31,27,0,'Dalmatiner: Charakter, Haltung & Wissenswertes zur Hunderasse',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1767738682,NULL,'',0,'','','Der Dalmatiner',0,0,0,0,0,'','',NULL,0,0,0,'/standard-content','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0),
(5,1,1767089318,1766786652,0,0,0,0,'',64,NULL,0,1,4,4,'{\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\"}',0,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"description\":\"\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"keywords\":\"\",\"l10n_source\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"nav_title\":\"\",\"newUntil\":\"0\",\"no_search\":\"0\",\"php_tree_stop\":\"0\",\"rowDescription\":\"\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"slug\":\"\\/standard-content\",\"starttime\":\"0\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"Standard Content\",\"tsconfig_includes\":\"\",\"url\":\"\"}',0,0,0,0,1,0,31,27,0,'The Dalmation',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1767089318,NULL,'',0,'','','',0,0,0,0,0,'','','',0,0,0,'/translate-to-german-standard-content','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0),
(6,1,1767089074,1767089053,0,1,0,0,'0',832,NULL,0,0,0,0,NULL,0,'',0,0,0,0,3,0,31,27,0,'Neu',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','','',0,0,0,'/neu','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0),
(7,1,1767733882,1767733878,0,0,0,0,'0',320,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,'Dackel',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1767733912,NULL,'',0,'','','',0,0,0,0,0,'','','',0,0,0,'/dackel','',0.5,'',0,0,'','','',NULL,'',NULL,0,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1766484317,1766484317,0,1,2,0,'/user_upload/SallyMohnfeld.jpg','7f40d358f3c77f4a70d16bdc5152a0885dca9646','19669f1e02c2f16705ec7587044c66443be70725','jpg','image/jpeg','SallyMohnfeld.jpg','1b615f14db0292e1cba4a358c3e0f2a922ec2072',168869,1766484317,1766484317),
(2,0,1766484326,1766484326,0,1,2,0,'/user_upload/SallySchnauze.jpg','5e90796af817a22c2ece26da98c8f6829bedefec','19669f1e02c2f16705ec7587044c66443be70725','jpg','image/jpeg','SallySchnauze.jpg','7ff313c4f096760c6da39b21c3605184579b236d',143856,1766484326,1766484326);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1766484317,1766484317,0,0,NULL,0,'',0,0,0,0,1,NULL,1200,900,NULL,NULL,0),
(2,0,1766484326,1766484326,0,0,NULL,0,'',0,0,0,0,2,NULL,1280,960,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1766484317,1766484317,1,1,'/_processed_/b/e/csm_SallyMohnfeld_b771ca0cb6.jpg','csm_SallyMohnfeld_b771ca0cb6.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','1b615f14db0292e1cba4a358c3e0f2a922ec2072','Image.CropScaleMask','b771ca0cb6',153,115),
(2,1766484326,1766484326,1,2,'/_processed_/b/5/preview_SallySchnauze_ba8d2ef55d.jpg','preview_SallySchnauze_ba8d2ef55d.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','7ff313c4f096760c6da39b21c3605184579b236d','Image.Preview','ba8d2ef55d',64,48),
(3,1766484329,1766484328,1,2,'/_processed_/b/5/csm_SallySchnauze_58da7ade57.jpg','csm_SallySchnauze_58da7ade57.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7ff313c4f096760c6da39b21c3605184579b236d','Image.CropScaleMask','58da7ade57',153,115),
(4,1766484336,1766484336,1,1,'/_processed_/b/e/csm_SallyMohnfeld_dfc4f5f3bf.jpg','csm_SallyMohnfeld_dfc4f5f3bf.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','1b615f14db0292e1cba4a358c3e0f2a922ec2072','Image.CropScaleMask','dfc4f5f3bf',200,150),
(5,1766484336,1766484336,1,1,'/_processed_/b/e/csm_SallyMohnfeld_c651a47f49.jpg','csm_SallyMohnfeld_c651a47f49.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','1b615f14db0292e1cba4a358c3e0f2a922ec2072','Image.CropScaleMask','c651a47f49',60,45),
(6,1766484364,1766484364,1,1,'/_processed_/b/e/csm_SallyMohnfeld_65f021491a.jpg','csm_SallyMohnfeld_65f021491a.jpg',NULL,'a:3:{s:5:\"width\";i:300;s:6:\"height\";i:225;s:4:\"crop\";N;}','86f8c2531d648c469525e037bd7759238643d1e6','1b615f14db0292e1cba4a358c3e0f2a922ec2072','Image.CropScaleMask','65f021491a',300,225),
(7,1766484373,1766484373,1,1,'/_processed_/b/e/csm_SallyMohnfeld_a43dab5da0.jpg','csm_SallyMohnfeld_a43dab5da0.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','1b615f14db0292e1cba4a358c3e0f2a922ec2072','Image.CropScaleMask','a43dab5da0',64,48),
(8,1766484408,1766484408,1,2,'/_processed_/b/5/csm_SallySchnauze_3f8c660385.jpg','csm_SallySchnauze_3f8c660385.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','7ff313c4f096760c6da39b21c3605184579b236d','Image.CropScaleMask','3f8c660385',200,150),
(9,1766484408,1766484408,1,2,'/_processed_/b/5/csm_SallySchnauze_c41d96a175.jpg','csm_SallySchnauze_c41d96a175.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','7ff313c4f096760c6da39b21c3605184579b236d','Image.CropScaleMask','c41d96a175',60,45),
(10,1766484415,1766484415,1,2,'/_processed_/b/5/csm_SallySchnauze_0e76d1b3bc.jpg','csm_SallySchnauze_0e76d1b3bc.jpg',NULL,'a:3:{s:5:\"width\";i:300;s:6:\"height\";i:225;s:4:\"crop\";N;}','86f8c2531d648c469525e037bd7759238643d1e6','7ff313c4f096760c6da39b21c3605184579b236d','Image.CropScaleMask','0e76d1b3bc',300,225),
(11,1766484430,1766484430,1,2,'/_processed_/b/5/csm_SallySchnauze_06e5ae2efd.jpg','csm_SallySchnauze_06e5ae2efd.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','7ff313c4f096760c6da39b21c3605184579b236d','Image.CropScaleMask','06e5ae2efd',64,48),
(12,1766787282,1766787282,1,1,'/_processed_/b/e/csm_SallyMohnfeld_1ae6fa1714.jpg','csm_SallyMohnfeld_1ae6fa1714.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:1200;s:9:\"\0*\0height\";d:900;}}','d4d5d54e04b136738d2811ff5e4d231a86588649','1b615f14db0292e1cba4a358c3e0f2a922ec2072','Image.CropScaleMask','1ae6fa1714',60,45);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,4,1767730360,1766484352,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,1,4,'tt_content','image',1,NULL,NULL,'Dalmatiner im Feld','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(2,4,1767730374,1766484414,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,2,6,'tt_content','image',1,NULL,NULL,'Dalmi Schnautze','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(3,4,1766787286,1766786709,0,0,1,1,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"4\",\"uid_local\":\"1\"}',0,0,0,0,1,9,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(4,4,1766787327,1766786709,0,0,1,2,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"6\",\"uid_local\":\"2\"}',0,0,0,0,2,11,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1731073824,1731073824,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`hash`),
  KEY `lookup_uid` (`ref_table`,`ref_uid`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('0a2b624127d51284a552bf8bf27a4e77','tt_content',11,'l18n_parent','','','',0,0,'tt_content',6,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('21f973e8229670917d408e565c8c47c4','sys_file_reference',3,'uid_local','','','',0,0,'sys_file',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('4ae2d7ea55a99746afe546e3292cfe66','tt_content',9,'l18n_parent','','','',0,0,'tt_content',4,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('680cc6b9d1cae7f1c3013ad894cb3f94','sys_file_reference',4,'uid_local','','','',0,0,'sys_file',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('74f89f508a8d8465607d030c6629dc92','sys_file_reference',1,'uid_local','','','',0,0,'sys_file',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('778da7f28be4226f197376b7579a4151','sys_file_reference',3,'l10n_parent','','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('9d757613c5a00e62bd1ed5df299fd53c','tt_content',8,'l18n_parent','','','',0,0,'tt_content',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('b61bfe2bd23bbddee76dd41aeaf0b5c7','sys_file_reference',4,'l10n_parent','','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('e3595e870a8b402d8071edf4009d6ee9','tt_content',11,'image','','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('e6567f7776ddd2e4c79fe8dfd636033b','tt_content',6,'image','','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('e723c1ee262ca5e04b8f72b38da18294','tt_content',12,'l18n_parent','','','',0,0,'tt_content',7,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('e979f5172b9aa804c27b98c901dc724c','sys_file_reference',2,'uid_local','','','',0,0,'sys_file',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('f0049ad46c773201e4ec1e71e9cc52cc','tt_content',9,'image','','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('f0f2fbc57925eea8f23d01c2162a11f8','tt_content',10,'l18n_parent','','','',0,0,'tt_content',5,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('f3ddf3ca3468578e58fd043656cdac25','tt_content',4,'image','','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('fd177625b48cd479237fb91c847a450d','pages',5,'l10n_parent','','','',0,0,'pages',4,'',0,0,2147483647,0,'',0,0,2147483647,0,0);
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PasswordPolicyForFrontendUsersUpdate','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),
(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(15,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:1;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:2;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";i:3;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(16,'extensionDataImport','or/typo3/cms-core/ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','or/typo3/cms-scheduler/ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','or/typo3/cms-extbase/ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','or/typo3/cms-fluid/ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','or/typo3/cms-install/ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','or/typo3/cms-backend/ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','or/typo3/cms-frontend/ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','or/typo3/cms-adminpanel/ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','or/typo3/cms-dashboard/ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','or/typo3/cms-fluid-styled-content/ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','or/typo3/cms-recycler/ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','or/typo3/cms-setup/ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','or/typo3/cms-rte-ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','or/typo3/cms-belog/ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','or/typo3/cms-beuser/ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','or/typo3/cms-extensionmanager/ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','or/typo3/cms-felogin/ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','or/typo3/cms-filelist/ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','or/typo3/cms-info/ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','or/typo3/cms-lowlevel/ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','or/typo3/cms-t3editor/ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','or/typo3/cms-tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','or/helhum/typo3-console/ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','or/ssch/typo3-debug-dump-pass/ext_tables_static+adt.sql','s:0:\"\";'),
(41,'core','formProtectionSessionToken:1','s:64:\"32a40f7bb30660f780d49099f7dca278103ebce1cca3c355c3195f373814f570\";'),
(43,'core','formProtectionSessionToken:3','s:64:\"291468ad8402583f37be3d50d43450550c4512f51e4b9fcf214f1193487aa5f5\";'),
(45,'languagePacks','de','i:1767089407;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` longtext DEFAULT NULL,
  `constants` longtext DEFAULT NULL,
  `config` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1766484261,1731073553,0,0,0,0,0,'This is an Empty Site Package TypoScript record.\r\n\r\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject/Configuration/TypoScript/setup.typoscript\'',0,'Main TypoScript Rendering',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/','','page = PAGE\r\npage.10 = TEXT\r\npage.10.value = <strong>in2mcp Development Environment</strong>\r\npage.100 = CONTENT\r\npage.100 {\r\n    table = tt_content\r\n    select {\r\n        orderBy = sorting\r\n        where = {#colPos}=0\r\n    }\r\n}\r\nconfig.contentObjectExceptionHandler = 0',NULL,0,0),
(2,4,1767731210,1767731101,0,0,0,0,256,'',0,'Temp',0,0,'','','page.meta.description = Alles über den Dalmatiner: Charakter, Aussehen, Geschichte und Besonderheiten der getupften Hunderasse. Erfahren Sie mehr über Haltung und Zucht.','',0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` longtext DEFAULT NULL,
  `pages` longtext DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `pi_flexform` longtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  `date` bigint(20) NOT NULL DEFAULT 0,
  `tx_in2glossar_exclude` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,'',1,1731080457,1731077417,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"colPos\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,'menu_subpages','Test cases','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(2,'',3,1764860261,1731077451,1,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"list_type\":\"\",\"pages\":\"\",\"recursive\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tx_in2glossar_exclude\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'list','Glossary','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'2',0,'','',0,0,'in2glossar_main',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(3,'',4,1767730868,1731080395,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'textpic','Der Dalmatiner','','<p>Kennen Sie die Hunderasse?</p>\r\n<p>Der Dalmatiner ist eine der bekanntesten und auffälligsten Hunderassen weltweit. Mit seinem charakteristischen weißen Fell und den schwarzen oder braunen Tupfen ist der Dalmatiner unverwechselbar. Erfahren Sie hier alles Wichtige über diese besondere Hunderasse.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,1,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(4,'',4,1767730360,1766484302,0,0,0,0,'',512,0,0,0,0,NULL,0,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'textpic','Beschreibung','','<p>Der Dalmatiner ist ein mittelgroßer bis großer, gut proportionierter, getupfter, kräftiger, lebhafter, sehr auffälliger <a href=\"https://de.wikipedia.org/wiki/Haushund\" title=\"Haushund\">Hund</a>. Sein ausgeglichener schlanker Körper besitzt einen starken Rücken mit einer gleichmäßigen geraden Rückenlinie. Der Dalmatiner hat muskulöse Schultern, einen langen, aber nicht allzu breiten Brustkorb und einen eleganten Hals. Seine Hängeohren sind mäßig groß, hoch angesetzt und liegen dicht am Kopf an. Seine Augen sind rund und sollten normalerweise bei Exemplaren mit schwarzen Flecken dunkelbraun sein. Leberbraunfarbene Hunde sollten bernsteinfarbene Augen haben. Die Rute des Dalmatiners ist sichelförmig. Sie ist lang, nach und nach schmaler werdend und reicht bis zu den Sprunggelenken. Einmalig unter den Hunderassen ist das Fell: weiß mit schwarzen bzw. braunen fest umrissenen Tupfen. Diese Färbung verdankt er einem sogenannten <a href=\"https://de.wikipedia.org/wiki/Scheckung\" title=\"Scheckung\">Scheckungs</a>-Gen.</p>',0,0,0,0,1,0,17,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(5,'',4,1766484386,1766484386,0,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,'textpic','Zuchtausschluß','','<p>Blaue und weiße Augen, beid- oder einseitig (Bicolor) werden traditionell als zuchtausschließende Fehler betrachtet, was vor der Änderung des Tierschutzgesetzes zur Tötung der Welpen durch die Züchter führen konnte. Hilfsweise wurde eine statistische oder sogar genetische Korrelation zu Taubheit behauptet, ist in der Literatur aber nicht nachgewiesen. Weitere unerwünschte Rassemerkmale und sogenannte zuchtausschließende Fehler sind zitronenfarbene<a href=\"https://de.wikipedia.org/wiki/Dalmatiner#cite_note-2\"><sup>[</sup><sup>2</sup><sup>]</sup></a> Flecken und das Vorhandensein von sowohl braunen als auch schwarzen Tupfen (Tricolor). Es wird empfohlen, taube und im Idealfall auch einseitig taube Hunde von der Zucht auszuschließen.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(6,'',4,1767730374,1766484414,0,0,0,0,'',1024,0,0,0,0,NULL,0,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'textpic','Geschichte','','<p>Erste Abbildungen von dalmatinerähnlichen Hunden gibt es schon in ägyptischen Pharaonengräbern. Manche Vermutungen gehen davon aus, dass der Dalmatiner von Indien über Ägypten und Griechenland in den westlichen Mittelmeerbereich und von dort nach Frankreich und England eingeführt wurde. In England war er während der viktorianischen Zeit als Kutschenbegleithund sehr populär. Später wurde er zum <a href=\"https://de.wikipedia.org/wiki/Maskottchen\" title=\"Maskottchen\">Maskottchen</a> der New Yorker Feuerwehr, indem er den im 19. Jahrhundert noch von Pferden gezogenen Feuerwehrwagen als lebende Sirene voraus lief.</p>\r\n<p>Es gibt mehrere Theorien, woher der Name Dalmatiner stammt; eine Theorie leitet sich von der <a href=\"https://de.wikipedia.org/wiki/Kroatien\" title=\"Kroatien\">kroatischen</a> Küstenregion <a href=\"https://de.wikipedia.org/wiki/Dalmatien\" title=\"Dalmatien\">Dalmatien</a> ab.</p>',0,0,0,0,1,0,17,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(7,'',4,1767730384,1766484456,0,0,0,0,'',1280,0,0,0,0,NULL,0,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'textpic','Taubheit','','<p>Die erste wissenschaftliche Untersuchung zur Taubheit beim Dalmatiner erschien 1896. Bereits 1769 hatte <a href=\"https://de.wikipedia.org/wiki/Georges-Louis_Leclerc_de_Buffon\" title=\"Georges-Louis Leclerc de Buffon\">Georges-Louis Leclerc de Buffon</a> im 5. Band seiner <i>Histoire naturelle générale et particulière</i> Taubheit bei Hunden mit weißem Fell in Verbindung gebracht.<a href=\"https://de.wikipedia.org/wiki/Dalmatiner#cite_note-4\"><sup>[4]</sup></a> Eine im Jahr 2000 in Deutschland durchgeführte und veröffentlichte Studie fand bei 1.899 Dalmatinern eine Taubheit von 19,7&nbsp;%, eine amerikanische Studie von 1992 fand bei 1.031 Dalmatinern eine Taubheit von 29,7&nbsp;%,<a href=\"https://de.wikipedia.org/wiki/Dalmatiner#cite_note-Strain-5\"><sup>[5]</sup></a>.</p>\r\n<p>Dalmatinerwelpe bei einer audiometrischen Untersuchung</p>\r\n<p>Die wichtigste Form ist die angeborene Innenohrschwerhörigkeit, die durch den Untergang bestimmter neuroepithelialer Strukturen (= Strukturen der Sinneszellen in den oberen Hautschichten) des Innenohrs gekennzeichnet ist. Die Schädigung entwickelt sich einseitig oder beidseitig als Folge einer Störung der Pigmentbildung nach der Geburt, während die Ohren und Augen der Welpen noch geschlossen sind, und wird meist in den ersten sechs bis acht Lebenswochen sichtbar. Die Erkrankung tritt häufiger bei blauäugigen Hunden und seltener bei Hunden mit Plattenzeichnung auf. Im Jahr 2000 wurde ein autosomal rezessives Hauptgen identifiziert, das für die Erkrankung verantwortlich ist.<a href=\"https://de.wikipedia.org/wiki/Dalmatiner#cite_note-6\"><sup>[6]</sup></a> Allerdings ist (Stand 2011) weder die genaue Anzahl der beteiligten Gene bekannt, noch ein für die Taubheit verantwortliches Gen eindeutig identifiziert. In den letzten Jahren konnte jedoch eine Eingrenzung auf bestimmte Regionen des Erbguts erreicht werden.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(8,'',4,1766786790,1766786709,0,0,0,0,'',384,0,1,3,3,NULL,0,'{\"CType\":\"textpic\",\"assets\":\"0\",\"bodytext\":\"<p>Kennen Sie die Hunderasse?<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Der Dalmatiner\",\"header_layout\":\"1\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"0\",\"imageorient\":\"0\",\"imagewidth\":\"0\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"list_type\":\"\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'textpic','The Dalmatian','','<p>Do you know the dog breed?</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,1,'',1,0,'',0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0',0,0),
(9,'',4,1766787286,1766786709,0,0,0,0,'',448,0,1,4,4,NULL,0,'{\"CType\":\"textpic\",\"assets\":\"0\",\"bodytext\":\"<p>Der Dalmatiner ist ein mittelgro\\u00dfer bis gro\\u00dfer, gut proportionierter, getupfter, kr\\u00e4ftiger, lebhafter, sehr auff\\u00e4lliger <a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Haushund\\\" title=\\\"Haushund\\\">Hund<\\/a>. Sein ausgeglichener schlanker K\\u00f6rper besitzt einen starken R\\u00fccken mit einer gleichm\\u00e4\\u00dfigen geraden R\\u00fcckenlinie. Der Dalmatiner hat muskul\\u00f6se Schultern, einen langen, aber nicht allzu breiten Brustkorb und einen eleganten Hals. Seine H\\u00e4ngeohren sind m\\u00e4\\u00dfig gro\\u00df, hoch angesetzt und liegen dicht am Kopf an. Seine Augen sind rund und sollten normalerweise bei Exemplaren mit schwarzen Flecken dunkelbraun sein. Leberbraunfarbene Hunde sollten bernsteinfarbene Augen haben. Die Rute des Dalmatiners ist sichelf\\u00f6rmig. Sie ist lang, nach und nach schmaler werdend und reicht bis zu den Sprunggelenken. Einmalig unter den Hunderassen ist das Fell: wei\\u00df mit schwarzen bzw. braunen fest umrissenen Tupfen. Diese F\\u00e4rbung verdankt er einem sogenannten <a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Scheckung\\\" title=\\\"Scheckung\\\">Scheckungs<\\/a>-Gen.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Beschreibung\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"1\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"0\",\"imageorient\":\"17\",\"imagewidth\":\"0\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"list_type\":\"\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'textpic','Description','','<p>The Dalmatian is a medium to large, well-proportioned, spotted, powerful, lively, and very striking dog. Its balanced, lean body has a strong back with a straight, even topline. The Dalmatian has muscular shoulders, a long but not overly broad chest, and an elegant neck. Its moderately large, drop ears are set high and lie close to the head. Its eyes are round and should normally be dark brown in dogs with black spots. Liver-colored dogs should have amber eyes. The Dalmatian\'s tail is sickle-shaped. It is long, gradually tapering, and reaches to the hocks. Unique among dog breeds is its coat: white with clearly defined black or brown spots. This coloring is due to a so-called piebald gene.</p>',0,0,0,0,1,0,17,2,0,0,0,'default',0,'','','','',0,'','',0,0,'',1,0,'',0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0',0,0),
(10,'',4,1766787310,1766786709,0,0,0,0,'',480,0,1,5,5,NULL,0,'{\"CType\":\"textpic\",\"assets\":\"0\",\"bodytext\":\"<p>Blaue und wei\\u00dfe Augen, beid- oder einseitig (Bicolor) werden traditionell als zuchtausschlie\\u00dfende Fehler betrachtet, was vor der \\u00c4nderung des Tierschutzgesetzes zur T\\u00f6tung der Welpen durch die Z\\u00fcchter f\\u00fchren konnte. Hilfsweise wurde eine statistische oder sogar genetische Korrelation zu Taubheit behauptet, ist in der Literatur aber nicht nachgewiesen. Weitere unerw\\u00fcnschte Rassemerkmale und sogenannte zuchtausschlie\\u00dfende Fehler sind zitronenfarbene<a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Dalmatiner#cite_note-2\\\"><sup>[<\\/sup><sup>2<\\/sup><sup>]<\\/sup><\\/a> Flecken und das Vorhandensein von sowohl braunen als auch schwarzen Tupfen (Tricolor). Es wird empfohlen, taube und im Idealfall auch einseitig taube Hunde von der Zucht auszuschlie\\u00dfen.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Zuchtausschlu\\u00df\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"0\",\"imageorient\":\"0\",\"imagewidth\":\"0\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"list_type\":\"\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'textpic','Breeding exclusion','','<p>Blue and white eyes, either in one or both eyes (bicolor), are traditionally considered disqualifying faults, which, before the amendment of the Animal Welfare Act, could lead to the killing of puppies by breeders. A statistical or even genetic correlation with deafness has been claimed as an alternative argument, but this has not been proven in the literature. Other undesirable breed characteristics and so-called disqualifying faults include lemon-colored[2] spots and the presence of both brown and black spots (tricolor). It is recommended that deaf dogs, and ideally also dogs with unilateral deafness, be excluded from breeding.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,0,'',1,0,'',0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0',0,0),
(11,'',4,1766787327,1766786709,0,0,0,0,'',496,0,1,6,6,NULL,0,'{\"CType\":\"textpic\",\"assets\":\"0\",\"bodytext\":\"<p>Erste Abbildungen von dalmatiner\\u00e4hnlichen Hunden gibt es schon in \\u00e4gyptischen Pharaonengr\\u00e4bern. Manche Vermutungen gehen davon aus, dass der Dalmatiner von Indien \\u00fcber \\u00c4gypten und Griechenland in den westlichen Mittelmeerbereich und von dort nach Frankreich und England eingef\\u00fchrt wurde. In England war er w\\u00e4hrend der viktorianischen Zeit als Kutschenbegleithund sehr popul\\u00e4r. Sp\\u00e4ter wurde er zum <a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Maskottchen\\\" title=\\\"Maskottchen\\\">Maskottchen<\\/a> der New Yorker Feuerwehr, indem er den im 19. Jahrhundert noch von Pferden gezogenen Feuerwehrwagen als lebende Sirene voraus lief.<\\/p>\\r\\n<p>Es gibt mehrere Theorien, woher der Name Dalmatiner stammt; eine Theorie leitet sich von der <a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Kroatien\\\" title=\\\"Kroatien\\\">kroatischen<\\/a> K\\u00fcstenregion <a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Dalmatien\\\" title=\\\"Dalmatien\\\">Dalmatien<\\/a> ab.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Geschichte\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"1\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"0\",\"imageorient\":\"17\",\"imagewidth\":\"0\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"list_type\":\"\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'textpic','History','','<p>The first depictions of Dalmatian-like dogs can be found in Egyptian pharaohs\' tombs. Some theories suggest that the Dalmatian was introduced from India via Egypt and Greece to the western Mediterranean region, and from there to France and England. In England, it was very popular as a carriage dog during the Victorian era. Later, it became the mascot of the New York City Fire Department, running ahead of the horse-drawn fire engines (which in the 19th century were still horse-drawn) as a living siren.</p>\r\n<p>There are several theories about the origin of the name Dalmatian; one theory derives it from the Croatian coastal region of Dalmatia.</p>',0,0,0,0,1,0,17,2,0,0,0,'default',0,'','','','',0,'','',0,0,'',1,0,'',0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0',0,0),
(12,'',4,1766787351,1766786709,0,0,0,0,'',504,0,1,7,7,NULL,0,'{\"CType\":\"textpic\",\"assets\":\"0\",\"bodytext\":\"<p>Die erste wissenschaftliche Untersuchung zur Taubheit beim Dalmatiner erschien 1896. Bereits 1769 hatte <a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Georges-Louis_Leclerc_de_Buffon\\\" title=\\\"Georges-Louis Leclerc de Buffon\\\">Georges-Louis Leclerc de Buffon<\\/a> im 5. Band seiner <i>Histoire naturelle g\\u00e9n\\u00e9rale et particuli\\u00e8re<\\/i> Taubheit bei Hunden mit wei\\u00dfem Fell in Verbindung gebracht.<a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Dalmatiner#cite_note-4\\\"><sup>[<\\/sup><sup>4<\\/sup><sup>]<\\/sup><\\/a> Eine im Jahr 2000 in Deutschland durchgef\\u00fchrte und ver\\u00f6ffentlichte Studie fand bei 1.899 Dalmatinern eine Taubheit von 19,7&nbsp;%, eine amerikanische Studie von 1992 fand bei 1.031 Dalmatinern eine Taubheit von 29,7&nbsp;%,<a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Dalmatiner#cite_note-Strain-5\\\"><sup>[<\\/sup><sup>5<\\/sup><sup>]<\\/sup><\\/a>.<\\/p>\\r\\n<p>Dalmatinerwelpe bei einer audiometrischen Untersuchung<\\/p>\\r\\n<p>Die wichtigste Form ist die angeborene Innenohrschwerh\\u00f6rigkeit, die durch den Untergang bestimmter neuroepithelialer Strukturen (= Strukturen der Sinneszellen in den oberen Hautschichten) des Innenohrs gekennzeichnet ist. Die Sch\\u00e4digung entwickelt sich einseitig oder beidseitig als Folge einer St\\u00f6rung der Pigmentbildung nach der Geburt, w\\u00e4hrend die Ohren und Augen der Welpen noch geschlossen sind, und wird meist in den ersten sechs bis acht Lebenswochen sichtbar. Die Erkrankung tritt h\\u00e4ufiger bei blau\\u00e4ugigen Hunden und seltener bei Hunden mit Plattenzeichnung auf. Im Jahr 2000 wurde ein autosomal rezessives Hauptgen identifiziert, das f\\u00fcr die Erkrankung verantwortlich ist.<a href=\\\"https:\\/\\/de.wikipedia.org\\/wiki\\/Dalmatiner#cite_note-6\\\"><sup>[<\\/sup><sup>6<\\/sup><sup>]<\\/sup><\\/a> Allerdings ist (Stand 2011) weder die genaue Anzahl der beteiligten Gene bekannt, noch ein f\\u00fcr die Taubheit verantwortliches Gen eindeutig identifiziert. In den letzten Jahren konnte jedoch eine Eingrenzung auf bestimmte Regionen des Erbguts erreicht werden.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Taubheit\",\"header_layout\":\"1\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"0\",\"imageorient\":\"0\",\"imagewidth\":\"0\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"list_type\":\"\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'textpic','Deafness','','<p>The first scientific study on deafness in Dalmatians was published in 1896. As early as 1769, Georges-Louis Leclerc de Buffon, in volume 5 of his *Histoire naturelle générale et particulière*, had linked deafness in dogs with white fur.[4] A study conducted and published in Germany in 2000 found 19.7% deafness in 1,899 Dalmatians, while an American study from 1992 found 29.7% deafness in 1,031 Dalmatians.[5]</p>\r\n<p>Dalmatian puppy during an audiometric examination</p>\r\n<p>The most important form is congenital sensorineural hearing loss, which is characterized by the degeneration of certain neuroepithelial structures (sensory cell structures in the upper layers of the skin) of the inner ear. The damage develops unilaterally or bilaterally as a result of a disruption in pigment formation after birth, while the puppies\' ears and eyes are still closed, and usually becomes visible in the first six to eight weeks of life. The condition occurs more frequently in blue-eyed dogs and less frequently in dogs with patchy markings. In 2000, a major autosomal recessive gene responsible for the condition was identified.[6] However, as of 2011, neither the exact number of genes involved nor a single gene responsible for deafness has been definitively identified. In recent years, however, it has been possible to narrow the focus to specific regions of the genome.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,1,'',1,0,'',0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0',0,0),
(13,'',4,1767731035,1767731035,0,0,0,0,'',1536,0,0,0,0,NULL,0,'',0,0,0,0,'html','','','<div class=\"frame frame-default frame-type-text frame-layout-0\">\r\n    <header>\r\n        <h2>Haltung und Pflege des Dalmatiners</h2>\r\n    </header>\r\n    <div class=\"ce-bodytext\">\r\n        <p>Der Dalmatiner ist ein aktiver und energiegeladener Hund, der viel Bewegung und Beschäftigung benötigt. Diese Hunderasse eignet sich besonders für sportliche Menschen, die gerne joggen, Rad fahren oder ausgedehnte Wanderungen unternehmen. Ein Dalmatiner braucht täglich mindestens zwei Stunden Auslauf, um seinen natürlichen Bewegungsdrang auszuleben.</p>\r\n        \r\n        <p>Die Pflege des Dalmatiners ist vergleichsweise unkompliziert. Das kurze, glatte Fell haart zwar das ganze Jahr über, lässt sich aber mit regelmäßigem Bürsten gut in den Griff bekommen. Baden sollte man den Dalmatiner nur bei Bedarf, um die natürliche Schutzschicht der Haut nicht zu zerstören.</p>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"frame frame-default frame-type-text frame-layout-0\">\r\n    <header>\r\n        <h2>Charakter und Wesen des Dalmatiners</h2>\r\n    </header>\r\n    <div class=\"ce-bodytext\">\r\n        <p>Der Dalmatiner zeichnet sich durch sein freundliches und aufgeschlossenes Wesen aus. Diese Hunderasse ist intelligent, lernwillig und möchte seinem Menschen gefallen. Dalmatiner sind sehr menschenbezogen und bauen eine enge Bindung zu ihrer Familie auf. Sie eignen sich gut als Familienhunde, wenn sie ausreichend beschäftigt werden.</p>\r\n        \r\n        <p>Wichtig ist bei der Erziehung des Dalmatiners eine konsequente, aber liebevolle Hand. Die Rasse kann manchmal etwas stur sein, reagiert aber sehr gut auf positive Verstärkung. Dalmatiner sind sensibel und sollten niemals mit Härte behandelt werden. Mit der richtigen Erziehung wird der Dalmatiner zu einem treuen und gehorsamen Begleiter.</p>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"frame frame-default frame-type-text frame-layout-0\">\r\n    <header>\r\n        <h2>Ernährung und Gesundheit beim Dalmatiner</h2>\r\n    </header>\r\n    <div class=\"ce-bodytext\">\r\n        <p>Bei der Ernährung des Dalmatiners gibt es einige Besonderheiten zu beachten. Die Rasse neigt zu Harnsteinen, weshalb eine purinarme Ernährung empfohlen wird. Hochwertiges Hundefutter mit einem ausgewogenen Protein- und Mineralstoffgehalt ist für den Dalmatiner besonders wichtig. Viele Züchter und Tierärzte empfehlen, auf Innereien und bestimmte Fleischsorten zu verzichten.</p>\r\n        \r\n        <p>Neben der Taubheit, die bei Dalmatinern gehäuft vorkommt, sind die meisten Vertreter dieser Rasse gesundheitlich robust. Regelmäßige tierärztliche Kontrollen, Impfungen und eine gute Vorsorge tragen dazu bei, dass der Dalmatiner ein langes und gesundes Leben führen kann. Die durchschnittliche Lebenserwartung liegt bei 10 bis 13 Jahren.</p>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"frame frame-default frame-type-text frame-layout-0\">\r\n    <header>\r\n        <h2>Dalmatiner als Familienhund</h2>\r\n    </header>\r\n    <div class=\"ce-bodytext\">\r\n        <p>Der Dalmatiner kann ein wunderbarer Familienhund sein, wenn die Rahmenbedingungen stimmen. Die Rasse ist kinderlieb und geduldig, benötigt aber genügend Platz und Beschäftigung. Ein Haus mit Garten ist ideal für die Haltung eines Dalmatiners, wobei auch eine Wohnungshaltung möglich ist, wenn ausreichend Bewegung geboten wird.</p>\r\n        \r\n        <p>Familien, die einen Dalmatiner halten möchten, sollten aktiv sein und gerne Zeit im Freien verbringen. Der Dalmatiner liebt es, überall dabei zu sein und am Familienleben teilzuhaben. Mit seiner fröhlichen und verspielten Art bringt der Dalmatiner viel Freude ins Haus und wird schnell zum vollwertigen Familienmitglied.</p>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"frame frame-default frame-type-text frame-layout-0\">\r\n    <header>\r\n        <h2>Dalmatiner kaufen: Worauf achten?</h2>\r\n    </header>\r\n    <div class=\"ce-bodytext\">\r\n        <p>Wer einen Dalmatiner kaufen möchte, sollte sich an seriöse Züchter wenden, die einem anerkannten Zuchtverband angehören. Ein verantwortungsvoller Züchter wird die Welpen auf Taubheit testen lassen und kann Auskunft über die Elterntiere und deren Gesundheit geben. Der Preis für einen Dalmatiner-Welpen liegt in der Regel zwischen 1.200 und 1.800 Euro.</p>\r\n        \r\n        <p>Alternativ kann man auch einem Dalmatiner aus dem Tierschutz eine Chance geben. Viele erwachsene Dalmatiner suchen ein neues Zuhause und freuen sich über eine zweite Chance. Wichtig ist in jedem Fall, dass man sich vor der Anschaffung ausführlich über die Bedürfnisse der Rasse informiert und sicherstellt, dass man dem Dalmatiner ein artgerechtes Leben bieten kann.</p>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"frame frame-default frame-type-text frame-layout-0\">\r\n    <header>\r\n        <h2>Fazit: Der Dalmatiner als besondere Hunderasse</h2>\r\n    </header>\r\n    <div class=\"ce-bodytext\">\r\n        <p>Der Dalmatiner ist zweifellos eine ganz besondere Hunderasse mit unverwechselbarem Aussehen und liebenswerten Charaktereigenschaften. Mit seinem getupften Fell und seinem eleganten Erscheinungsbild zieht der Dalmatiner überall die Blicke auf sich. Doch hinter der schönen Fassade steckt ein anspruchsvoller Hund, der viel Bewegung, konsequente Erziehung und eine enge Bindung zu seinen Menschen braucht.</p>\r\n        \r\n        <p>Für aktive Menschen und Familien, die bereit sind, Zeit und Energie in die Haltung zu investieren, ist der Dalmatiner ein treuer und fröhlicher Begleiter. Mit der richtigen Pflege, Ernährung und Beschäftigung wird der Dalmatiner zu einem glücklichen und ausgeglichenen Familienmitglied, das viele Jahre Freude bereitet.</p>\r\n    </div>\r\n</div>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(14,'',4,1767731287,1767731287,0,0,0,0,'',1792,0,0,0,0,NULL,0,'',0,0,0,0,'html','','','<script type=\"application/ld+json\">\r\n{\r\n  \"@context\": \"https://schema.org\",\r\n  \"@type\": \"Article\",\r\n  \"headline\": \"Der Dalmatiner - Charakter, Haltung & Wissenswertes zur Hunderasse\",\r\n  \"description\": \"Alles über den Dalmatiner: Charakter, Aussehen, Geschichte und Besonderheiten der getupften Hunderasse. Erfahren Sie mehr über Haltung und Zucht.\",\r\n  \"image\": [\r\n    \"https://example.com/fileadmin/_processed_/b/e/csm_SallyMohnfeld_65f021491a.jpg\",\r\n    \"https://example.com/fileadmin/_processed_/b/5/csm_SallySchnauze_0e76d1b3bc.jpg\"\r\n  ],\r\n  \"author\": {\r\n    \"@type\": \"Organization\",\r\n    \"name\": \"in2code GmbH\"\r\n  },\r\n  \"publisher\": {\r\n    \"@type\": \"Organization\",\r\n    \"name\": \"in2code GmbH\",\r\n    \"logo\": {\r\n      \"@type\": \"ImageObject\",\r\n      \"url\": \"https://example.com/logo.png\"\r\n    }\r\n  },\r\n  \"datePublished\": \"2025-01-06\",\r\n  \"dateModified\": \"2025-01-06\",\r\n  \"mainEntityOfPage\": {\r\n    \"@type\": \"WebPage\",\r\n    \"@id\": \"https://example.com/dalmatiner\"\r\n  }\r\n}\r\n</script>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(15,'',7,1767733895,1767733895,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'header','Der Dackel (Teckel)','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),
(16,'',7,1767733912,1767733912,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'textpic','','','<p>Die <strong>Dackel</strong>, auch <strong>Dachshund</strong> oder vor allem in der <a href=\"https://de.wikipedia.org/wiki/J%C3%A4gersprache\" title=\"Jägersprache\">Jägersprache</a> <strong>Teckel</strong> genannt, sind neun von der <a href=\"https://de.wikipedia.org/wiki/F%C3%A9d%C3%A9ration_Cynologique_Internationale\" title=\"Fédération Cynologique Internationale\">FCI</a> anerkannte deutsche <a href=\"https://de.wikipedia.org/wiki/Hunderasse\" title=\"Hunderasse\">Hunderassen</a> (<a href=\"https://de.wikipedia.org/wiki/Hunderassen_in_der_Systematik_der_FCI\" title=\"Hunderassen in der Systematik der FCI\">FCI-Gruppe&nbsp;4, Sektion&nbsp;1, Standard Nr.&nbsp;148)</a>.</p>\r\n<p>Die Rassen werden in drei unterschiedlichen Fellformen und drei unterschiedlichen Größenformen gezüchtet, woraus die neun verschiedenen Rassen definieren, welche regulär nicht miteinander gekreuzt werden und zudem unterschiedliche genetische Herkünfte vorweisen. Die Zucht findet in Deutschland hauptsächlich im <a href=\"https://de.wikipedia.org/wiki/Deutscher_Teckelklub_1888\" title=\"Deutscher Teckelklub 1888\"><i>Deutschen Teckelklub 1888</i></a>, im <a href=\"https://de.wikipedia.org/wiki/Internationaler_Rasse-Jagd-Gebrauchshundeverband\" title=\"Internationaler Rasse-Jagd-Gebrauchshundeverband\">Internationalen Rasse-Jagd-Gebrauchshundeverband</a> und – als rein jagdliche Zucht – im <i>Verein für Jagdteckel</i><a href=\"https://de.wikipedia.org/wiki/Dackel#cite_note-VJT-1\"><sup>[</sup><sup>1</sup><sup>]</sup></a> statt.</p>\r\n<p>Der Begriff <i>Dachshund</i> bezeichnet neben der Hunderasse auch eine <a href=\"https://de.wikipedia.org/wiki/Jagdhund#Historische_Nutzungsgruppen\" title=\"Jagdhund\">historische Nutzungsgruppe von Jagdhunden</a>: zum einen Hunde, die zur <a href=\"https://de.wikipedia.org/wiki/Jagdhund#Unter_der_Erde\" title=\"Jagdhund\">Baujagd</a> (<a href=\"https://de.wikipedia.org/wiki/Erdhund\" title=\"Erdhund\">Erdhund</a>), nicht aber speziell zur Jagd im Dachsbau eingesetzt wurden, denn <a href=\"https://de.wikipedia.org/wiki/Dachse\" title=\"Dachse\">Dachse</a> sind sehr wehrhaft und damit gefährlich für die Erdhunde. Vielmehr ist der Namensbestandteil Dachs eine übergreifende Hunderassenbezeichnung als ein Hinweis auf die Größe der Hunde und eine Gruppe (Gruppe 4: Dachshunde) in der <a href=\"https://de.wikipedia.org/wiki/Hunderassen_in_der_Systematik_der_FCI\" title=\"Hunderassen in der Systematik der FCI\">Rassesystematik der FCI</a>, die dort jedoch nur die Rasse <i>Dachshund</i> enthält. Weitere Namensträger sind die Westfälische Dachsbracke und die Alpenländische Dachsbracke, bei denen es sich nicht um Rassen der Gruppe Erdhunde handelt.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` longtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_in2glossar_domain_model_definition`
--

DROP TABLE IF EXISTS `tx_in2glossar_domain_model_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_in2glossar_domain_model_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `word` varchar(255) NOT NULL DEFAULT '',
  `synonyms` tinytext NOT NULL,
  `short_description` tinytext NOT NULL,
  `description` text NOT NULL,
  `tooltip` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_in2glossar_domain_model_definition`
--

LOCK TABLES `tx_in2glossar_domain_model_definition` WRITE;
/*!40000 ALTER TABLE `tx_in2glossar_domain_model_definition` DISABLE KEYS */;
INSERT INTO `tx_in2glossar_domain_model_definition` VALUES
(1,2,1731507046,1731077732,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Australia','Commonwealth of Australia','Australian continent','<p><strong>Australia</strong>, officially the <strong>Commonwealth of Australia</strong>, is a country comprising the mainland of the Australian continent, the island of Tasmania and numerous smaller islands. Australia has a total area of 7,688,287&nbsp;km<sup>2</sup> (2,968,464&nbsp;sq&nbsp;mi), making it the sixth-largest country in the world and the largest country by area in Oceania. It is the world\'s oldest, flattest, and driest inhabited continent, with some of the least fertile soils. It is a megadiverse country, and its size gives it a wide variety of landscapes and climates including deserts in the interior and tropical rainforests along the coast.</p>',1),
(2,2,1731079238,1731077778,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','England','United Kingdom','Great Britain','<p><strong>England</strong> is a country that is part of the United Kingdom. It is located on the island of Great Britain, of which it covers about 62%, and more than 100 smaller adjacent islands. It has land borders with Scotland to the north and Wales to the west, and is otherwise surrounded by the North Sea to the east, the English Channel to the south, the Celtic Sea to the south-west, and the Irish Sea to the west. Continental Europe lies to the south-east, and Ireland to the west. At the 2021 census, the population was 56,490,048. London is both the largest city and the capital.</p>',0),
(3,2,1731079253,1731077867,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','India','Republic of India','South Asia','<p><strong>India</strong>, officially the <strong>Republic of India</strong>, is a country in South Asia. It is the seventh-largest country in the world by area and the most populous country. Bounded by the Indian Ocean on the south, the Arabian Sea on the southwest, and the Bay of Bengal on the southeast, it shares land borders with Pakistan to the west; China, Nepal, and Bhutan to the north; and Bangladesh and Myanmar to the east. In the Indian Ocean, India is in the vicinity of Sri Lanka and the Maldives; its Andaman and Nicobar Islands share a maritime border with Thailand, Myanmar, and Indonesia.</p>\r\n\r\n\r\n\r\n',0),
(4,2,1731079285,1731077917,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Mexico','United Mexican States','southern portion of North America','<p><strong>Mexico</strong>, officially the <strong>United Mexican States</strong>, is a country in the southern portion of North America. Covering 1,972,550&nbsp;km<sup>2</sup> (761,610 sq mi), it is the world\'s 13th largest country by area; with a population of almost 130 million, it is the 10th most populous country and has the most Spanish speakers in the world. Mexico is a constitutional republic comprising 31 states and Mexico City, its capital and largest city, which is among the world\'s most populous metropolitan areas. The country shares land borders with the United States to the north, with Guatemala and Belize to the southeast; as well as maritime borders with the Pacific Ocean to the west, the Caribbean Sea to the southeast, and the Gulf of Mexico to the east.</p>',0),
(5,2,1731322606,1731077946,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Poland','Republic of Poland','country of Poland','<p><strong>Poland</strong>, officially the <strong>Republic of Poland</strong>, is a country in Central Europe. It extends from the Baltic Sea in the north to the Sudetes and Carpathian Mountains in the south, bordered by Lithuania and Russia to the northeast, Belarus and Ukraine to the east, Slovakia and the Czech Republic to the south, and Germany to the west. The territory is characterised by a varied landscape, diverse ecosystems, and temperate transitional climate. Poland is composed of sixteen voivodeships and is the fifth most populous member state of the European Union (EU), with over 38 million people, and the fifth largest EU country by land area, covering a combined area of 312,696&nbsp;km<sup>2</sup> (120,733&nbsp;sq&nbsp;mi). The capital and largest city is Warsaw; other major cities include Kraków, Wrocław, Łódź, Poznań, and Gdańsk.</p>',0),
(6,2,1731322668,1731077999,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Romania','Romania','Romania','<p><strong>Romania</strong> is a country located at the crossroads of Central, Eastern, and Southeast Europe. It borders Ukraine to the north and east, Hungary to the west, Serbia to the southwest, Bulgaria to the south, Moldova to the east, and the Black Sea to the southeast. It has a mainly continental climate, and an area of 238,397&nbsp;km<sup>2</sup> (92,046&nbsp;sq&nbsp;mi) with a population of 19 million people (2023). Romania is the twelfth-largest country in Europe and the sixth-most populous member state of the European Union. Europe\'s second-longest river, the Danube, empties into the Danube Delta in the southeast of the country. The Carpathian Mountains cross Romania from the north to the southwest and include Moldoveanu Peak, at an altitude of 2,544&nbsp;m (8,346&nbsp;ft). Romania\'s capital and largest city is Bucharest. Other major urban centers include Cluj-Napoca, Timișoara, Iași, Constanța and Brașov.</p>',0),
(7,2,1731322745,1731078045,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Turkey','Republic of Türkiye','West Asia','<p><strong>Turkey</strong>, officially the <strong>Republic of Türkiye,</strong> is a country mainly located in Anatolia in West Asia, with a smaller part called East Thrace in Southeast Europe. It borders the Black Sea to the north; Georgia, Armenia, Azerbaijan, and Iran to the east; Iraq, Syria, and the Mediterranean Sea to the south; and the Aegean Sea, Greece, and Bulgaria to the west. Turkey is home to over 85 million people; most are ethnic Turks, while ethnic Kurds are the largest ethnic minority. Officially a secular state, Turkey has a Muslim-majority population. Ankara is Turkey\'s capital and second-largest city, while Istanbul is its largest city and economic and financial center. Other major cities include İzmir, Bursa, and Antalya.</p>',0),
(8,2,1731323467,1731322802,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','USA','United States of America','America','<p>The <strong>United States of America</strong> (<strong>USA</strong>), commonly known as the <strong>United States</strong> (<strong>U.S.</strong>) or <strong>America</strong>, is a country primarily located in North America. It is a federal union of 50 states and a federal capital district, Washington, D.C. The 48 contiguous states border Canada to the north and Mexico to the south, with the states of Alaska to the northwest and the archipelagic Hawaii in the Pacific Ocean. The United States also asserts sovereignty over five major island territories and various uninhabited islands. The country has the world\'s third-largest land area, largest exclusive economic zone, and third-largest population, exceeding 334 million. Its three largest metropolitan areas are New York, Los Angeles, and Chicago, and its three most populous states are California, Texas, and Florida.</p>',0),
(9,2,1731323559,1731323553,1,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','','xc','fd','<p>cdsc</p>',0),
(10,2,1731323639,1731323633,1,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','A','Ab','Ab','<p>AB</p>',0),
(11,2,1736950104,1736949730,0,0,0,0,0,0,NULL,'{\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\",\"starttime\":\"\",\"endtime\":\"\"}','Brazil','Federative Republic of Brazil','','<p>Brazil, officially the Federative Republic of Brazil, is the largest country in both South America and Latin America. It spans an area of 8,515,767 square kilometers, making it the world\'s fifth-largest country by area. It is bordered by the Atlantic Ocean to the east and shares borders with every South American country except Chile and Ecuador. Brazil is renowned for its diverse ecosystems, including the Amazon rainforest, which is recognized for its biodiversity and significance for global climate.</p>',0),
(12,2,1736950129,1736950129,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Canada','Canada','','<p>Canada is the second-largest country in the world by total area, spanning 9,984,670 square kilometers. It is located in North America and is bordered by the United States to the south and the Arctic Ocean to the north. Canada is known for its vast landscapes, including forests, mountain ranges, and lakes. It is a bilingual country, with English and French as its official languages.</p>',0),
(13,2,1736950155,1736950155,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Denmark','Kingdom of Denmark','','<p>Denmark, officially the Kingdom of Denmark, is a Nordic country in Northern Europe. It is situated southwest of Sweden and south of Norway, and it borders Germany to the south. Denmark consists of a peninsula, Jutland, and an archipelago of 443 named islands. The country is known for its high standard of living and strong social welfare systems.</p>',0),
(14,2,1736950195,1736950195,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','France','French Republic','','<p>France, officially the French Republic, is a country located in Western Europe, with territories in several overseas regions and territories. It is bordered by Belgium, Luxembourg, Germany, Switzerland, Italy, and Spain. France is renowned for its cultural heritage, including art, fashion, cuisine, and history. Paris, its capital, is one of the most visited cities in the world.</p>',0),
(15,2,1736950237,1736950237,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Germany','Federal Republic of Germany','','<p>Germany, officially the Federal Republic of Germany, is a country in Central Europe. It is bordered by Denmark to the north, Poland and the Czech Republic to the east, Austria and Switzerland to the south, and France, Luxembourg, Belgium, and the Netherlands to the west. Germany is known for its rich history, cultural contributions, and economic strength as the largest economy in Europe.</p>',0),
(16,2,1736950266,1736950266,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Hungary','Hungary','','<p>Hungary is a landlocked country in Central Europe, bordered by Austria, Slovakia, Ukraine, Romania, Serbia, Croatia, and Slovenia. It is known for its cultural heritage, historic architecture, and contributions to music and literature. Budapest, its capital, is famous for its thermal baths and the Danube River.</p>',0),
(17,2,1736950283,1736950283,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Japan','Japan','','<p>Japan is an island country in East Asia, located in the northwest Pacific Ocean. It is made up of four main islands—Honshu, Hokkaido, Kyushu, and Shikoku—along with numerous smaller islands. Japan is known for its unique blend of traditional and modern culture, including historic temples and advanced technology. Tokyo, its capital, is one of the largest metropolitan areas in the world.</p>',0),
(18,2,1736950315,1736950315,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Kenya','Republic of Kenya','','<p>Kenya, officially the Republic of Kenya, is a country in East Africa. It is bordered by Tanzania, Uganda, South Sudan, Ethiopia, and Somalia, with a coastline along the Indian Ocean. Kenya is famous for its wildlife, national parks, and the Great Rift Valley. Nairobi, its capital, serves as a hub for commerce and culture.</p>',0),
(19,2,1736950344,1736950344,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Luxembourg','Grand Duchy of Luxembourg','','<p>Luxembourg, officially the Grand Duchy of Luxembourg, is a small landlocked country in Western Europe. It borders Belgium, France, and Germany. Despite its size, Luxembourg has a strong economy and is one of the world\'s wealthiest countries. The country is known for its medieval old town and financial sector.</p>',0),
(20,2,1736950366,1736950366,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Norway','Kingdom of Norway','','<p>Norway, officially the Kingdom of Norway, is a Nordic country located in Northern Europe. It shares borders with Sweden, Finland, and Russia. Known for its stunning fjords, mountains, and coastline, Norway is a country with a high standard of living and strong environmental policies.</p>',0),
(21,2,1736950391,1736950391,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Oman','Sultanate of Oman','','<p>Oman, officially the Sultanate of Oman, is a country on the southeastern coast of the Arabian Peninsula. It is bordered by the United Arab Emirates, Saudi Arabia, and Yemen, with a coastline along the Arabian Sea and the Gulf of Oman. Oman is known for its historic forts, desert landscapes, and traditional culture.</p>',0),
(22,2,1736950424,1736950424,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Spain','Kingdom of Spain','','<p>Spain, officially the Kingdom of Spain, is a country in Southwestern Europe. It shares borders with Portugal, France, Andorra, and Gibraltar, with coastlines along the Atlantic Ocean and the Mediterranean Sea. Known for its historic cities, art, and cuisine, Spain is also famous for cultural traditions such as flamenco and bullfighting.</p>',0),
(23,2,1736950465,1736950465,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Vietnam','Socialist Republic of Vietnam','','<p>Vietnam, officially the Socialist Republic of Vietnam, is a country in Southeast Asia. It is bordered by China, Laos, and Cambodia, with a coastline along the South China Sea. Vietnam is known for its history, cuisine, and natural beauty, including Ha Long Bay and the Mekong Delta.</p>',0),
(24,2,1736950488,1736950488,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Yemen','Republic of Yemen','','<p>Yemen, officially the Republic of Yemen, is a country on the southern end of the Arabian Peninsula. It is bordered by Saudi Arabia and Oman, with a coastline along the Red Sea and the Arabian Sea. Known for its ancient cities like Sana\'a, Yemen has a rich history and diverse cultural heritage.</p>',0),
(25,2,1736950509,1736950509,0,0,0,0,0,0,NULL,'{\"starttime\":\"\",\"endtime\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"tooltip\":\"\",\"word\":\"\",\"synonyms\":\"\",\"short_description\":\"\",\"description\":\"\"}','Zambia','Republic of Zambia','','<p>Zambia, officially the Republic of Zambia, is a landlocked country in Southern Africa. It is bordered by Tanzania, Malawi, Mozambique, Zimbabwe, Botswana, Namibia, Angola, and the Democratic Republic of Congo. Zambia is known for its wildlife, national parks, and Victoria Falls, one of the Seven Natural Wonders of the World.</p>',0);
/*!40000 ALTER TABLE `tx_in2glossar_domain_model_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `nextexecution` bigint(20) NOT NULL DEFAULT 0,
  `lastexecution_time` bigint(20) NOT NULL DEFAULT 0,
  `lastexecution_failure` longtext DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tasktype` longtext DEFAULT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `execution_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`execution_details`)),
  `number_of_days` int(11) NOT NULL DEFAULT 0,
  `selected_tables` varchar(4000) DEFAULT '',
  `file_storage` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_backends` longtext DEFAULT NULL,
  `max_file_count` int(10) unsigned NOT NULL DEFAULT 0,
  `ip_mask` int(10) unsigned NOT NULL DEFAULT 2,
  `all_tables` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `color` varchar(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-02 13:02:41
